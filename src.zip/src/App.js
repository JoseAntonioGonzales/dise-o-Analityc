import Bienvenido from './Inicio/Bienvenido';
import './App.css';

function App() {
  return (
    <>
      <Bienvenido/>
      
    </>
  );
}

export default App;

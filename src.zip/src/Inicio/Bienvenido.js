import React, { useState, useEffect } from "react";
import ApiGetFunction from "../Functions/ApiGetFunction";

function Inicio() {
    const [sucursales, setSucursales] = useState([]);
    const [tiposVenta, setTiposVenta] = useState([]);
    const [cadenas, setCadenas] = useState([]);
    const [ventaInfo, setVentaInfo] = useState(null);
    const [selectedCadena, setSelectedCadena] = useState("");
    const [selectedSucursal, setSelectedSucursal] = useState("");
    const [selectedTipoVenta, setSelectedTipoVenta] = useState("");
    const [fechaInicio, setFechaInicio] = useState("");
    const [fechaFin, setFechaFin] = useState("");

    useEffect(() => {
        const fetchData = async () => {
            const sucursalesData = await getOpticas();
            setSucursales(sucursalesData);

            const tiposVentaData = await getTiposVenta();
            setTiposVenta(tiposVentaData);

            const cadenasData = await getCadenas();
            setCadenas(cadenasData);
        };

        fetchData();
    }, []);

    const getOpticas = async () => {
        try {
            const response = await ApiGetFunction('sucursales');
            return response.map(sucursal => ({
                id: sucursal._id,
                nombre: sucursal.nombre,
                flag: sucursal.flag
            }));
        } catch (error) {
            console.log('Error en getOpticas:', error);
            return [];
        }
    };

    const getTiposVenta = async () => {
        try {
            const response = await ApiGetFunction('tipoVenta');
            return response.map(tipo => ({
                id: tipo._id,
                nombre: tipo.nombre
            }));
        } catch (error) {
            console.log('Error en getTiposVenta:', error);
            return [];
        }
    };

    const getCadenas = async () => {
        try {
            const response = await ApiGetFunction('cadenas');
            return response.map(cadena => ({
                id: cadena._id,
                nombre: cadena.nombre
            }));
        } catch (error) {
            console.log('Error en getCadenas:', error);
            return [];
        }
    };

    const getVentaById = async (id, tipoVenta, fechaInicio, fechaFin) => {
        try {
            return await ApiGetFunction('ventaId', { id, tipoVenta, fechaInicio, fechaFin });
        } catch (error) {
            console.log('Error en getVentaById:', error);
            return null;
        }
    };

    const handleSearch = async () => {
        const ventaData = await getVentaById(selectedSucursal, selectedTipoVenta, fechaInicio, fechaFin);
        setVentaInfo(ventaData);
    };

    return (
        <div className="p-6 bg-gray-100 min-h-screen">
            <div className="bg-white p-6 rounded-lg shadow-lg mb-6">
                <div className="flex justify-start mb-4">
                    <button onClick={handleSearch} className="border p-2 rounded-lg bg-blue-500 text-white shadow-md hover:bg-blue-600 transition duration-200">Buscar</button>
                </div>
                <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="p-4 border rounded-lg bg-gray-50 shadow-md">
                        <div className="grid grid-cols-2 gap-4">
                            <div className="col-span-2">
                                <label className="block mb-1">Cadena:</label>
                                <select onChange={(e) => setSelectedCadena(e.target.value)} className="border p-2 rounded-lg w-full">
                                    <option value="">Seleccione una cadena</option>
                                    {cadenas.map(cadena => (
                                        <option key={cadena.id} value={cadena.id}>{cadena.nombre}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-span-2">
                                <label className="block mb-1">Sucursal:</label>
                                <select onChange={(e) => setSelectedSucursal(e.target.value)} className="border p-2 rounded-lg w-full">
                                    <option value="">Seleccione una sucursal</option>
                                    {sucursales.map(sucursal => (
                                        <option key={sucursal.id} value={sucursal.id}>{sucursal.nombre}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-span-2">
                                <label className="block mb-1">Tipo de Venta:</label>
                                <select onChange={(e) => setSelectedTipoVenta(e.target.value)} className="border p-2 rounded-lg w-full">
                                    <option value="">Seleccione un tipo de venta</option>
                                    {tiposVenta.map(tipo => (
                                        <option key={tipo.id} value={tipo.id}>{tipo.nombre}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-span-1">
                                <label className="block mb-1">Fechas Desde:</label>
                                <input type="date" className="border p-2 rounded-lg w-full" value={fechaInicio} onChange={(e) => setFechaInicio(e.target.value)} />
                            </div>
                            <div className="col-span-1">
                                <label className="block mb-1">Fechas Hasta:</label>
                                <input type="date" className="border p-2 rounded-lg w-full" value={fechaFin} onChange={(e) => setFechaFin(e.target.value)} />
                            </div>
                        </div>
                    </div>
                    <div className="p-4 border rounded-lg bg-gray-50 shadow-md">
                        <div className="grid grid-cols-2 gap-4">
                            <div className="col-span-2">
                                <label className="block mb-1">Cadena:</label>
                                <select onChange={(e) => setSelectedCadena(e.target.value)} className="border p-2 rounded-lg w-full">
                                    <option value="">Seleccione una cadena</option>
                                    {cadenas.map(cadena => (
                                        <option key={cadena.id} value={cadena.id}>{cadena.nombre}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-span-2">
                                <label className="block mb-1">Sucursal:</label>
                                <select onChange={(e) => setSelectedSucursal(e.target.value)} className="border p-2 rounded-lg w-full">
                                    <option value="">Seleccione una sucursal</option>
                                    {sucursales.map(sucursal => (
                                        <option key={sucursal.id} value={sucursal.id}>{sucursal.nombre}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-span-2">
                                <label className="block mb-1">Tipo de Venta:</label>
                                <select onChange={(e) => setSelectedTipoVenta(e.target.value)} className="border p-2 rounded-lg w-full">
                                    <option value="">Seleccione un tipo de venta</option>
                                    {tiposVenta.map(tipo => (
                                        <option key={tipo.id} value={tipo.id}>{tipo.nombre}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="col-span-1">
                                <label className="block mb-1">Fechas Desde:</label>
                                <input type="date" className="border p-2 rounded-lg w-full" />
                            </div>
                            <div className="col-span-1">
                                <label className="block mb-1">Fechas Hasta:</label>
                                <input type="date" className="border p-2 rounded-lg w-full" />
                            </div>
                        </div>
                    </div>
                </div>
                {ventaInfo && (
                    <div className="bg-white p-6 rounded-lg shadow-lg mt-6">
                        <h2 className="text-xl text-gray-800 mb-4">Información de la Venta</h2>
                        <pre className="bg-gray-100 p-4 rounded-lg text-gray-700">{JSON.stringify(ventaInfo, null, 2)}</pre>
                    </div>
                )}
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg mb-6">
                <div className="flex items-start">
                    <div className="pr-4">
                        <h2 className="text-2xl font-bold mb-4">Ventas Bs</h2>
                        <div className="flex items-center mt-14">
                            <div className="bg-green-500 text-white px-6 py-1 rounded-l-md">LENTES</div>
                        </div>
                        <div className="flex items-center mt-2">
                            <div className="bg-green-500 text-white px-6 py-1 rounded-l-md">LC</div>
                        </div>
                        <div className="flex items-center mt-2">
                            <div className="bg-green-500 text-white px-6 py-1 rounded-l-md">GAFAS</div>
                        </div>
                        <div className="flex items-center mt-2">
                            <div className="bg-green-500 text-white px-6 py-1 rounded-l-md">OTROS</div>
                        </div>
                    </div>
                    <div className="flex-1">
                        <table className="w-full table-auto border-collapse">
                            <thead>
                                <tr>
                                    <th className="border px-4 py-2 bg-teal-600 text-white text-right">27/11/2014</th>
                                    <th className="border px-4 py-2 bg-teal-600 text-white text-right">Meta</th>
                                    <th className="border px-4 py-2 bg-teal-600 text-white text-right">28/11/2015</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr className="bg-gray-100">
                                    <td className="border px-4 py-2 text-right">$ 486.986</td>
                                    <td className="border px-4 py-2 text-right">$ 538.129</td>
                                    <td className="border px-4 py-2 text-right">$ 330.973</td>
                                </tr>
                                <tr>
                                    <td className="border px-4 py-2 text-right">$ 191.325</td>
                                    <td className="border px-4 py-2 text-right">$ 218.033</td>
                                    <td className="border px-4 py-2 text-right">$ 190.585</td>
                                </tr>
                                <tr className="bg-gray-100">
                                    <td className="border px-4 py-2 text-right">$ 20.193</td>
                                    <td className="border px-4 py-2 text-right">$ 24.226</td>
                                    <td className="border px-4 py-2 text-right">$ 190.585</td>
                                </tr>
                                <tr>
                                    <td className="border px-4 py-2 text-right">$ 71.911</td>
                                    <td className="border px-4 py-2 text-right">$ 92.684</td>
                                    <td className="border px-4 py-2 text-right">$ 38.367</td>
                                </tr>
                                <tr className="bg-gray-100">
                                    <td className="border px-4 py-2 text-right">$ 204.192</td>
                                    <td className="border px-4 py-2 text-right">$ 183.445</td>
                                    <td className="border px-4 py-2 text-right">$ 104.739</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div className="grid grid-cols-6 gap-4 p-4 border rounded-lg bg-gray-100 shadow-md">
                    {[
                    "CANT SUCURSALES",
                    "TOTAL VENTA",
                    "TCP",
                    "VENTA X DIA",
                    "TKT PROMEDIO",
                    "TRAFICO"
                    ].map((title, index) => (
                    <div key={index} className="p-3 border rounded-lg bg-white shadow-sm flex flex-col items-center justify-center">
                        <h3 className="text-xs font-bold text-center text-gray-800 mb-2">{title}</h3>
                        <span className="text-lg font-semibold text-blue-600">0</span>
                    </div>
                    ))}
                </div>
                <div className="grid grid-cols-6 gap-4 p-4 border rounded-lg bg-gray-100 shadow-md">
                    {[
                    "TRAFICO",
                    "TKT PROMEDIO",
                    "VENTA X DIA",
                    "TCP",
                    "TOTAL VENTA",
                    "CANTIDAD SUCURSALES"
                    ].map((title, index) => (
                    <div key={index} className="p-3 border rounded-lg bg-white shadow-sm flex flex-col items-center justify-center">
                        <h3 className="text-xs font-bold text-center text-gray-800 mb-2">{title}</h3>
                        <span className="text-lg font-semibold text-blue-600">0</span>
                    </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

export default Inicio;
